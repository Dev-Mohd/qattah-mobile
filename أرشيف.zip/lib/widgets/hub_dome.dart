import 'package:flutter/material.dart';

import '../core/theme/hesabna_theme.dart';

class HubDomeItem {
  final IconData icon;
  final String label;

  const HubDomeItem(this.icon, this.label);
}

class HesabnaHubDome extends StatefulWidget {
  final Animation<double> animation;
  final List<HubDomeItem> items;
  final int initialIndex;
  final void Function(int index) onSelect;

  const HesabnaHubDome({
    super.key,
    required this.animation,
    required this.items,
    required this.onSelect,
    this.initialIndex = 0,
  });

  @override
  State<HesabnaHubDome> createState() => _HesabnaHubDomeState();
}

class _HesabnaHubDomeState extends State<HesabnaHubDome> {
  late int _centerIndex;
  double _dragOffset = 0;

  @override
  void initState() {
    super.initState();
    _centerIndex = widget.initialIndex;
  }

  void _onDragUpdate(DragUpdateDetails details) {
    setState(() => _dragOffset += details.delta.dx);
  }

  void _onDragEnd(DragEndDetails _) {
    const threshold = 60.0;
    if (_dragOffset < -threshold && _centerIndex < widget.items.length - 1) {
      setState(() => _centerIndex++);
    } else if (_dragOffset > threshold && _centerIndex > 0) {
      setState(() => _centerIndex--);
    }
    setState(() => _dragOffset = 0);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.animation,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, (1 - widget.animation.value) * 80),
        child: Opacity(
          opacity: widget.animation.value,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
            decoration: BoxDecoration(
              color: context.cSurface,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(HesabnaRadius.xl2),
              ),
              border: Border.all(color: context.cBorder),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(
                    alpha: context.isDark ? 0.4 : 0.08,
                  ),
                  blurRadius: 24,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 36,
                    height: 4,
                    decoration: BoxDecoration(
                      color: context.cBorder,
                      borderRadius: BorderRadius.circular(HesabnaRadius.full),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onHorizontalDragUpdate: _onDragUpdate,
                  onHorizontalDragEnd: _onDragEnd,
                  child: SizedBox(
                    height: 90,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(widget.items.length, (index) {
                        final distance = (index - _centerIndex).abs();
                        final scale =
                            distance == 0 ? 1.0 : (distance == 1 ? 0.72 : 0.55);
                        final opacity =
                            distance == 0 ? 1.0 : (distance == 1 ? 0.50 : 0.22);
                        final item = widget.items[index];
                        final active = index == _centerIndex;

                        return Flexible(
                          flex: distance == 0 ? 3 : (distance == 1 ? 2 : 1),
                          child: GestureDetector(
                            onTap: () => active
                                ? widget.onSelect(_centerIndex)
                                : setState(() => _centerIndex = index),
                            child: AnimatedOpacity(
                              duration: const Duration(milliseconds: 200),
                              opacity: opacity,
                              child: AnimatedScale(
                                scale: scale,
                                duration: const Duration(milliseconds: 200),
                                curve: Curves.easeOutCubic,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 52,
                                      height: 52,
                                      decoration: BoxDecoration(
                                        color: active
                                            ? context.accentColor
                                            : context.cHover,
                                        borderRadius: BorderRadius.circular(
                                          HesabnaRadius.lg,
                                        ),
                                      ),
                                      child: Icon(
                                        item.icon,
                                        size: 22,
                                        color: active
                                            ? context.cBg
                                            : context.cTextSub,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      item.label,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: HesabnaTypography.caption(
                                        color: active
                                            ? context.cText
                                            : context.cTextSub,
                                      ).copyWith(
                                        fontWeight: active
                                            ? FontWeight.w700
                                            : FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(widget.items.length, (index) {
                    final active = index == _centerIndex;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: active ? 16 : 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: active ? context.accentColor : context.cBorder,
                        borderRadius: BorderRadius.circular(HesabnaRadius.full),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 8),
                Text(
                  widget.items[_centerIndex].label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: HesabnaTypography.bodySm(color: context.accentColor)
                      .copyWith(fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
