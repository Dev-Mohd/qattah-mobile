import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme/hesabna_theme.dart';

// ════════════════════════════════════════════════════════════════════
//  APP BOTTOM BAR — الشريط السفلي الموحد لكل الشاشات
//
//  الاستخدام في HomeScreen / SettingsScreen:
//    bottomNavigationBar: AppBottomBar(activeScreen: ActiveScreen.home)
//
//  الاستخدام في ListShellScreen:
//    AppBottomBar(
//      activeScreen: ActiveScreen.list,
//      domeOpen:     _domeOpen,
//      onDomeTap:    _toggleDome,
//      onFabTap:     () => context.goToAttendance(listId),
//      showFab:      _currentIndex == 0 && !_domeOpen,
//    )
// ════════════════════════════════════════════════════════════════════

enum ActiveScreen { home, lists, list, settings }

class AppBottomBar extends StatelessWidget {
  final ActiveScreen activeScreen;

  // خاص بـ ListShellScreen فقط
  final bool domeOpen;
  final VoidCallback? onDomeTap;
  final VoidCallback? onFabTap;
  final bool showFab;

  final VoidCallback onHomeTap;
  final VoidCallback onSettingsTap;
  final VoidCallback onManageTap;

  const AppBottomBar({
    super.key,
    required this.activeScreen,
    this.domeOpen = false,
    this.onDomeTap,
    this.onFabTap,
    this.showFab = false,
    required this.onHomeTap,
    required this.onSettingsTap,
    required this.onManageTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: context.cSurface,
        border: Border(top: BorderSide(color: context.cBorder)),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 60,
          child: Row(
            children: [
              // ── الرئيسية ──────────────────────────────────────────
              Expanded(
                child: AppNavItem(
                  icon: Icons.home_outlined,
                  active: activeScreen == ActiveScreen.home,
                  label: 'الرئيسية',
                  onTap: onHomeTap,
                ),
              ),

              // ── إدارة (Hub) ────────────────────────────────────────
              if (activeScreen == ActiveScreen.list && onDomeTap != null)
                AppHubButton(open: domeOpen, onTap: onDomeTap!)
              else if (activeScreen == ActiveScreen.home)
                AppHubButton(
                  open: false,
                  icon: Icons.list_alt_outlined,
                  label: 'القوائم',
                  onTap: onManageTap,
                )
              else if (activeScreen == ActiveScreen.lists)
                AppHubButton(
                  open: true,
                  icon: Icons.list_alt_outlined,
                  label: 'القوائم',
                  onTap: onManageTap,
                )
              else if (activeScreen == ActiveScreen.settings)
                AppHubButton(
                  open: false,
                  icon: Icons.list_alt_outlined,
                  label: 'القوائم',
                  onTap: onManageTap,
                )
              else
                AppHubButton(open: false, onTap: onManageTap),

              // ── FAB أو الإعدادات ───────────────────────────────────
              Expanded(
                child: activeScreen == ActiveScreen.list &&
                        showFab &&
                        onFabTap != null
                    ? AppFabItem(onTap: onFabTap!)
                    : AppNavItem(
                        icon: Icons.settings_outlined,
                        active: activeScreen == ActiveScreen.settings,
                        label: 'الإعدادات',
                        onTap: onSettingsTap,
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════
//  NAV ITEM
// ════════════════════════════════════════════════════════════════════

class AppNavItem extends StatelessWidget {
  final IconData icon;
  final bool active;
  final String label;
  final VoidCallback onTap;

  const AppNavItem({
    super.key,
    required this.icon,
    required this.active,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 22,
            color: active ? context.accentColor : context.cTextSub,
          ),
          const SizedBox(height: 3),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: HesabnaTypography.caption(
              color: active ? context.accentColor : context.cTextSub,
            ).copyWith(
              fontWeight: active ? FontWeight.w700 : FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════
//  HUB BUTTON
// ════════════════════════════════════════════════════════════════════

class AppHubButton extends StatelessWidget {
  final bool open;
  final VoidCallback onTap;
  final IconData icon;
  final String label;

  const AppHubButton({
    super.key,
    required this.open,
    required this.onTap,
    this.icon = Icons.apps_rounded,
    this.label = 'إدارة',
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        open ? HapticFeedback.lightImpact() : HapticFeedback.mediumImpact();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        constraints: const BoxConstraints(maxWidth: 116),
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: open ? context.cText : context.cHover,
          borderRadius: BorderRadius.circular(HesabnaRadius.full),
          border: Border.all(
            color: open ? context.cText : context.cBorder,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedRotation(
              turns: open ? 0.125 : 0,
              duration: const Duration(milliseconds: 200),
              child: Icon(
                icon,
                size: 18,
                color: open ? context.cBg : context.cTextSub,
              ),
            ),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: HesabnaTypography.bodySm(
                  color: open ? context.cBg : context.cTextSub,
                ).copyWith(fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════
//  FAB ITEM
// ════════════════════════════════════════════════════════════════════

class AppFabItem extends StatelessWidget {
  final VoidCallback onTap;
  const AppFabItem({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.heavyImpact();
        onTap();
      },
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: context.accentColor,
              borderRadius: BorderRadius.circular(HesabnaRadius.md),
            ),
            child: Icon(Icons.add, color: context.cBg, size: 20),
          ),
          const SizedBox(height: 3),
          Text(
            'وجبة',
            style: HesabnaTypography.caption(color: context.accentColor)
                .copyWith(fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}
