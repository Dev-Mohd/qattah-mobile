import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

class DatabaseManager {
  static Database? _database;
  static bool _schemaEnsured = false;
  static final DatabaseManager instance = DatabaseManager._internal();

  DatabaseManager._internal();

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }
    _database = await _initDatabase();
    if (!_schemaEnsured) {
      await _ensureSchema(_database!);
      _schemaEnsured = true;
    }
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final documentsDirectory = await getApplicationDocumentsDirectory();
    final path = join(documentsDirectory.path, 'qattah.db');

    return await openDatabase(
      path,
      version: 3,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
      onOpen: (db) async {
        if (!_schemaEnsured) {
          await _ensureSchema(db);
          _schemaEnsured = true;
        }
      },
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE lists (
        id TEXT PRIMARY KEY NOT NULL,
        name TEXT NOT NULL,
        color TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE members (
        id TEXT PRIMARY KEY NOT NULL,
        list_id TEXT NOT NULL,
        name TEXT NOT NULL,
        opening_balance REAL NOT NULL DEFAULT 0,
        is_default_attendee INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (list_id) REFERENCES lists(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE meal_types (
        id TEXT PRIMARY KEY NOT NULL,
        list_id TEXT NOT NULL,
        name TEXT NOT NULL,
        default_price REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (list_id) REFERENCES lists(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE records (
        id TEXT PRIMARY KEY NOT NULL,
        list_id TEXT NOT NULL,
        meal_type_id TEXT,
        meal_name TEXT NOT NULL,
        date TEXT NOT NULL,
        total_amount REAL NOT NULL,
        per_person REAL NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (list_id) REFERENCES lists(id) ON DELETE CASCADE,
        FOREIGN KEY (meal_type_id) REFERENCES meal_types(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE record_participants (
        id TEXT PRIMARY KEY NOT NULL,
        record_id TEXT NOT NULL,
        member_id TEXT,
        member_name TEXT NOT NULL,
        share REAL NOT NULL,
        created_at TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (record_id) REFERENCES records(id) ON DELETE CASCADE,
        FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE payments (
        id TEXT PRIMARY KEY NOT NULL,
        list_id TEXT NOT NULL,
        member_id TEXT,
        member_name TEXT NOT NULL,
        amount REAL NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (list_id) REFERENCES lists(id) ON DELETE CASCADE,
        FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('CREATE INDEX idx_records_list_date ON records(list_id, date)');
    await db.execute('CREATE INDEX idx_participants_record ON record_participants(record_id)');
    await db.execute('CREATE INDEX idx_participants_member ON record_participants(member_id)');
    await db.execute('CREATE INDEX idx_payments_list ON payments(list_id)');
    await db.execute('CREATE INDEX idx_payments_member ON payments(member_id)');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    await _ensureSchema(db);
    _schemaEnsured = true;
  }

  Future<void> _ensureSchema(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS payments (
        id TEXT PRIMARY KEY NOT NULL,
        list_id TEXT NOT NULL,
        member_id TEXT,
        member_name TEXT NOT NULL,
        amount REAL NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (list_id) REFERENCES lists(id) ON DELETE CASCADE,
        FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL
      )
    ''');
    await _ensureColumn(
      db,
      table: 'lists',
      column: 'color',
      definition: "TEXT NOT NULL DEFAULT '#2563EB'",
    );
    await _ensureColumn(
      db,
      table: 'lists',
      column: 'created_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'lists',
      column: 'updated_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'members',
      column: 'opening_balance',
      definition: 'REAL NOT NULL DEFAULT 0',
    );
    await _ensureColumn(
      db,
      table: 'members',
      column: 'is_default_attendee',
      definition: 'INTEGER NOT NULL DEFAULT 1',
    );
    await _ensureColumn(
      db,
      table: 'members',
      column: 'created_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'members',
      column: 'updated_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'meal_types',
      column: 'default_price',
      definition: 'REAL NOT NULL DEFAULT 0',
    );
    await _ensureColumn(
      db,
      table: 'meal_types',
      column: 'created_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'meal_types',
      column: 'updated_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'records',
      column: 'meal_type_id',
      definition: 'TEXT',
    );
    await _ensureColumn(
      db,
      table: 'records',
      column: 'meal_name',
      definition: "TEXT NOT NULL DEFAULT 'وجبة'",
    );
    await _ensureColumn(
      db,
      table: 'records',
      column: 'total_amount',
      definition: 'REAL NOT NULL DEFAULT 0',
    );
    await _ensureColumn(
      db,
      table: 'records',
      column: 'per_person',
      definition: 'REAL NOT NULL DEFAULT 0',
    );
    await _ensureColumn(
      db,
      table: 'records',
      column: 'note',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'records',
      column: 'created_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'records',
      column: 'updated_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'record_participants',
      column: 'member_name',
      definition: "TEXT NOT NULL DEFAULT 'عضو'",
    );
    await _ensureColumn(
      db,
      table: 'record_participants',
      column: 'share',
      definition: 'REAL NOT NULL DEFAULT 0',
    );
    await _ensureColumn(
      db,
      table: 'record_participants',
      column: 'created_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await _ensureColumn(
      db,
      table: 'record_participants',
      column: 'updated_at',
      definition: "TEXT NOT NULL DEFAULT ''",
    );
    await db.execute('CREATE INDEX IF NOT EXISTS idx_records_list_date ON records(list_id, date)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_participants_record ON record_participants(record_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_participants_member ON record_participants(member_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_payments_list ON payments(list_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_payments_member ON payments(member_id)');
  }

  Future<void> _ensureColumn(
    Database db, {
    required String table,
    required String column,
    required String definition,
  }) async {
    final columns = await db.rawQuery('PRAGMA table_info($table)');
    final exists = columns.any((c) => c['name'] == column);
    if (!exists) {
      await db.execute('ALTER TABLE $table ADD COLUMN $column $definition');
    }
  }

  Future<void> close() async {
    final db = await database;
    await db.close();
    _database = null;
    _schemaEnsured = false;
  }

  Future<void> deleteAll() async {
    final db = await database;
    await db.delete('payments');
    await db.delete('record_participants');
    await db.delete('records');
    await db.delete('meal_types');
    await db.delete('members');
    await db.delete('lists');
  }
}
