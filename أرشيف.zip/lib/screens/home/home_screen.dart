import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/currency.dart';
import '../../core/onboarding.dart';
import '../../core/router.dart';
import '../../core/theme/hesabna_theme.dart';
import '../../models/member_model.dart';
import '../../models/payment_model.dart';
import '../../models/record_model.dart';
import '../../providers/providers.dart';

final homeOverviewProvider =
    FutureProvider.autoDispose<HomeOverview>((ref) async {
  ref.cacheFor(const Duration(minutes: 5));

  final lists = await ref.watch(listsProvider.future);
  final memberRepo = ref.watch(memberRepositoryProvider);
  final paymentRepo = ref.watch(paymentRepositoryProvider);
  final recordRepo = ref.watch(recordRepositoryProvider);

  var monthExpenseTotal = 0.0;
  var monthPaymentTotal = 0.0;
  var monthRecords = 0;
  var monthPayments = 0;
  var memberCount = 0;
  final activities = <HomeActivity>[];
  final monthKey = DateTime.now().toIso8601String().substring(0, 7);

  final snapshots = await Future.wait(lists.map((list) async {
    final results = await Future.wait([
      memberRepo.getByListId(list.id),
      recordRepo.getByListId(list.id),
      paymentRepo.getByListId(list.id),
    ]);
    return _HomeListSnapshot(
      members: results[0] as List<MemberModel>,
      records: results[1] as List<RecordModel>,
      payments: results[2] as List<PaymentModel>,
    );
  }));

  for (final snapshot in snapshots) {
    final members = snapshot.members;
    final records = snapshot.records;
    final payments = snapshot.payments;
    final monthListRecords =
        records.where((r) => r.date.startsWith(monthKey)).toList();
    final monthListPayments =
        payments.where((p) => p.createdAt.startsWith(monthKey)).toList();
    final listTotal =
        monthListRecords.fold<double>(0, (sum, r) => sum + r.totalAmount);
    final paymentTotal =
        monthListPayments.fold<double>(0, (sum, p) => sum + p.amount);

    memberCount += members.length;
    monthRecords += monthListRecords.length;
    monthPayments += monthListPayments.length;
    monthExpenseTotal += listTotal;
    monthPaymentTotal += paymentTotal;
    activities.addAll(records.take(2).map(HomeActivity.record));
    activities.addAll(payments.take(2).map(HomeActivity.payment));
  }

  activities.sort((a, b) => b.sortKey.compareTo(a.sortKey));

  return HomeOverview(
    listCount: lists.length,
    monthExpenseTotal: monthExpenseTotal,
    monthPaymentTotal: monthPaymentTotal,
    monthRecords: monthRecords,
    monthPayments: monthPayments,
    memberCount: memberCount,
    recentActivities: activities.take(5).toList(),
  );
});

class _HomeListSnapshot {
  final List<MemberModel> members;
  final List<RecordModel> records;
  final List<PaymentModel> payments;

  const _HomeListSnapshot({
    required this.members,
    required this.records,
    required this.payments,
  });
}

class HomeOverview {
  final int listCount;
  final double monthExpenseTotal;
  final double monthPaymentTotal;
  final int monthRecords;
  final int monthPayments;
  final int memberCount;
  final List<HomeActivity> recentActivities;

  double get monthNetTotal => monthExpenseTotal - monthPaymentTotal;

  const HomeOverview({
    required this.listCount,
    required this.monthExpenseTotal,
    required this.monthPaymentTotal,
    required this.monthRecords,
    required this.monthPayments,
    required this.memberCount,
    required this.recentActivities,
  });
}

enum HomeActivityType { record, payment }

class HomeActivity {
  final HomeActivityType type;
  final RecordModel? record;
  final PaymentModel? payment;

  const HomeActivity._({
    required this.type,
    this.record,
    this.payment,
  });

  factory HomeActivity.record(RecordModel record) {
    return HomeActivity._(type: HomeActivityType.record, record: record);
  }

  factory HomeActivity.payment(PaymentModel payment) {
    return HomeActivity._(type: HomeActivityType.payment, payment: payment);
  }

  String get sortKey {
    switch (type) {
      case HomeActivityType.record:
        final value =
            record!.createdAt.isNotEmpty ? record!.createdAt : record!.date;
        return value;
      case HomeActivityType.payment:
        return payment!.createdAt;
    }
  }
}

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _openOnboardingIfNeeded());
  }

  Future<void> _openOnboardingIfNeeded() async {
    final prefs = await SharedPreferences.getInstance();
    final seen = prefs.getBool(onboardingSeenKey) ?? false;
    if (seen || !mounted) return;
    context.goToOnboarding();
  }

  @override
  Widget build(BuildContext context) {
    final overviewAsync = ref.watch(homeOverviewProvider);
    final creatorName = ref.watch(creatorNameValueProvider);
    final reminder = ref.watch(reminderProvider);

    return Scaffold(
      body: SafeArea(
        child: overviewAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, _) => _HomeError(message: err.toString()),
          data: (overview) => CustomScrollView(
            slivers: [
              SliverPadding(
                padding: EdgeInsets.fromLTRB(
                  context.pagePad,
                  18,
                  context.pagePad,
                  HesabnaSpacing.bottomNavPad,
                ),
                sliver: SliverList.list(
                  children: [
                    _GreetingHeader(
                      name: creatorName,
                      reminder: reminder,
                    ),
                    SizedBox(height: context.sectionGap),
                    _BalanceCard(overview: overview),
                    const SizedBox(height: 12),
                    _StatsRow(overview: overview),
                    SizedBox(height: context.sectionGap),
                    _SectionHeader(
                      title: 'آخر نشاط',
                      action: 'القوائم',
                      onAction: () => context.goToLists(),
                    ),
                    const SizedBox(height: 10),
                    if (overview.recentActivities.isEmpty)
                      _EmptyActivityView(onCreateTap: () => context.goToLists())
                    else
                      ...overview.recentActivities.map((activity) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: _ActivityTile(activity: activity),
                          )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: null,
    );
  }
}

class _GreetingHeader extends StatelessWidget {
  final String name;
  final ReminderSettings reminder;
  const _GreetingHeader({
    required this.name,
    required this.reminder,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('السلام عليكم',
                  style: HesabnaTypography.caption(color: context.cTextSub)),
              const SizedBox(height: 2),
              Text(name,
                  style: HesabnaTypography.heading(color: context.cText)),
            ],
          ),
        ),
        _IconButton(
          icon: reminder.enabled
              ? Icons.notifications_active_outlined
              : Icons.notifications_none,
          active: reminder.enabled,
          onTap: () => _showReminderSheet(context),
        ),
        const SizedBox(width: 8),
        CircleAvatar(
          radius: 20,
          backgroundColor: context.cAccentSoft,
          child: Text(
            name.isEmpty ? 'ق' : name.characters.first,
            style: HesabnaTypography.subtitle(color: context.accentColor),
          ),
        ),
      ],
    );
  }

  void _showReminderSheet(BuildContext context) {
    final timeLabel = TimeOfDay(
      hour: reminder.hour,
      minute: reminder.minute,
    ).format(context);

    showModalBottomSheet(
      context: context,
      backgroundColor: context.cBg,
      shape: const RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(HesabnaRadius.xl)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: reminder.enabled
                          ? context.cAccentSoft
                          : context.cHover,
                      borderRadius: BorderRadius.circular(HesabnaRadius.md),
                    ),
                    child: Icon(
                      reminder.enabled
                          ? Icons.notifications_active_outlined
                          : Icons.notifications_none,
                      color: reminder.enabled
                          ? context.accentColor
                          : context.cTextSub,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          reminder.enabled ? 'التذكير مفعل' : 'التذكير متوقف',
                          style:
                              HesabnaTypography.heading(color: context.cText),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          reminder.enabled
                              ? 'سيصلك تذكير يومياً الساعة $timeLabel'
                              : 'فعّل التذكير اليومي من الإعدادات.',
                          style: HesabnaTypography.caption(
                              color: context.cTextSub),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(sheetContext);
                  context.goToSettings();
                },
                icon: const Icon(Icons.settings_outlined),
                label:
                    Text(reminder.enabled ? 'تعديل التذكير' : 'تفعيل التذكير'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BalanceCard extends StatelessWidget {
  final HomeOverview overview;
  const _BalanceCard({required this.overview});

  @override
  Widget build(BuildContext context) {
    return HesabnaCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('المتبقي هذا الشهر',
                  style: HesabnaTypography.caption(color: context.cTextSub)),
              const Spacer(),
              _StatusPill(
                  text:
                      '${overview.monthRecords} وجبة · ${overview.monthPayments} سداد'),
            ],
          ),
          const SizedBox(height: 10),
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: Text(
              formatCurrency(overview.monthNetTotal, decimals: 2),
              textDirection: TextDirection.ltr,
              style: HesabnaTypography.amountHero(
                color: overview.monthNetTotal > 0
                    ? HesabnaColors.lightDanger
                    : overview.monthNetTotal < 0
                        ? HesabnaColors.lightSuccess
                        : context.cText,
              ),
            ),
          ),
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: Text(saudiRiyalSymbol,
                style: HesabnaTypography.caption(color: context.cTextSub)),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _MiniAmount(
                  label: 'مصاريف',
                  value: overview.monthExpenseTotal,
                  color: context.accentColor),
              const SizedBox(width: 8),
              _MiniAmount(
                  label: 'سداد',
                  value: overview.monthPaymentTotal,
                  color: HesabnaColors.lightSuccess),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatsRow extends StatelessWidget {
  final HomeOverview overview;
  const _StatsRow({required this.overview});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
            child: _StatTile(label: 'قوائم', value: '${overview.listCount}')),
        const SizedBox(width: 8),
        Expanded(
            child: _StatTile(label: 'أعضاء', value: '${overview.memberCount}')),
        const SizedBox(width: 8),
        Expanded(
            child:
                _StatTile(label: 'سدادات', value: '${overview.monthPayments}')),
      ],
    );
  }
}

class _MiniAmount extends StatelessWidget {
  final String label;
  final double value;
  final Color color;

  const _MiniAmount({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: color.withValues(alpha: context.isDark ? 0.16 : 0.10),
          borderRadius: BorderRadius.circular(HesabnaRadius.sm),
        ),
        child: Row(
          children: [
            Expanded(
                child: Text(label,
                    style: HesabnaTypography.caption(color: context.cTextSub))),
            Text(
              formatCurrency(value),
              textDirection: TextDirection.ltr,
              style: HesabnaTypography.label(color: color),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final String label;
  final String value;
  const _StatTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return HesabnaCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: HesabnaTypography.caption(color: context.cTextSub)),
          const SizedBox(height: 4),
          Text(value, style: HesabnaTypography.title(color: context.cText)),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String? action;
  final VoidCallback? onAction;

  const _SectionHeader({required this.title, this.action, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(title, style: HesabnaTypography.subtitle(color: context.cText)),
        const Spacer(),
        if (action != null)
          TextButton.icon(
            onPressed: onAction,
            icon: const Icon(Icons.arrow_back, size: 16),
            label: Text(action!),
          ),
      ],
    );
  }
}

class _ActivityTile extends StatelessWidget {
  final HomeActivity activity;
  const _ActivityTile({required this.activity});

  @override
  Widget build(BuildContext context) {
    final isPayment = activity.type == HomeActivityType.payment;
    final record = activity.record;
    final payment = activity.payment;
    final title = isPayment ? 'سداد ${payment!.memberName}' : record!.mealName;
    final subtitle = isPayment ? _dateOnly(payment!.createdAt) : record!.date;
    final amount = isPayment ? payment!.amount : record!.totalAmount;
    final icon = isPayment ? Icons.payments_outlined : Icons.receipt_long;
    final color = isPayment ? HesabnaColors.lightSuccess : context.accentColor;

    return Container(
      constraints: BoxConstraints(minHeight: context.rowHeight),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: context.cCard,
        borderRadius: BorderRadius.circular(HesabnaRadius.tile),
        border: Border.all(color: context.cBorder),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor:
                color.withValues(alpha: context.isDark ? 0.18 : 0.10),
            child: Icon(icon, size: 18, color: color),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: HesabnaTypography.subtitle(color: context.cText)),
                Text(subtitle,
                    style: HesabnaTypography.caption(color: context.cTextSub)),
              ],
            ),
          ),
          Text(
            '${isPayment ? '-' : ''}${amount.toStringAsFixed(0)}',
            textDirection: TextDirection.ltr,
            style: HesabnaTypography.amountSmall(color: color),
          ),
        ],
      ),
    );
  }

  String _dateOnly(String value) {
    final date = DateTime.tryParse(value);
    if (date == null) return value.length > 10 ? value.substring(0, 10) : value;
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }
}

class _EmptyActivityView extends StatelessWidget {
  final VoidCallback onCreateTap;
  const _EmptyActivityView({required this.onCreateTap});

  @override
  Widget build(BuildContext context) {
    return HesabnaCard(
      padding: EdgeInsets.symmetric(horizontal: context.cardPad, vertical: 34),
      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: context.cHover,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Icon(Icons.local_cafe_outlined, color: context.cTextSub),
          ),
          const SizedBox(height: 18),
          Text('لا توجد أنشطة بعد',
              style: HesabnaTypography.title(color: context.cText)),
          const SizedBox(height: 8),
          Text(
            'افتح صفحة القوائم، أضف أعضاءك، ثم سجل أول وجبة.',
            textAlign: TextAlign.center,
            style: HesabnaTypography.bodySm(color: context.cTextSub),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: onCreateTap,
            icon: const Icon(Icons.add),
            label: const Text('فتح القوائم'),
          ),
        ],
      ),
    );
  }
}

class _HomeError extends StatelessWidget {
  final String message;
  const _HomeError({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(context.pagePad),
        child: HesabnaCard(
          child: Text('تعذر تحميل الصفحة: $message',
              style: HesabnaTypography.body(color: context.cText)),
        ),
      ),
    );
  }
}

class _IconButton extends StatelessWidget {
  final IconData icon;
  final bool active;
  final VoidCallback onTap;
  const _IconButton({
    required this.icon,
    required this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(HesabnaRadius.md),
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: context.cCard,
          borderRadius: BorderRadius.circular(HesabnaRadius.md),
          border:
              Border.all(color: active ? context.accentColor : context.cBorder),
        ),
        child: Icon(icon,
            size: 20, color: active ? context.accentColor : context.cText),
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  final String text;
  const _StatusPill({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: context.cAccentSoft,
        borderRadius: BorderRadius.circular(HesabnaRadius.full),
      ),
      child: Text(text,
          style: HesabnaTypography.label(color: context.accentColor)),
    );
  }
}
