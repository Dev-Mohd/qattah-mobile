import 'dart:io';

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/backup_service.dart';
import '../../core/theme/hesabna_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/app_widgets.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeValueProvider);
    final accentColor = ref.watch(accentColorValueProvider);
    final density = ref.watch(densityValueProvider);
    final cardStyle = ref.watch(cardStyleValueProvider);
    final creatorName = ref.watch(creatorNameValueProvider);
    final reminder = ref.watch(reminderProvider);

    return Scaffold(
      body: ListView(
        padding: EdgeInsets.fromLTRB(
          context.pagePad,
          context.pagePad,
          context.pagePad,
          HesabnaSpacing.bottomNavPad,
        ),
        children: [
          const SizedBox(height: 18),
          Text('الإعدادات',
              style: HesabnaTypography.heading(color: context.cText)),
          Text('اضبط شكل التطبيق وطريقة عرضه',
              style: HesabnaTypography.caption(color: context.cTextSub)),
          SizedBox(height: context.sectionGap),
          _SettingsSection(
            title: 'المظهر',
            children: [
              _SettingBlock(
                icon: Icons.dark_mode_outlined,
                title: 'الوضع',
                subtitle: 'فاتح، داكن، أو حسب النظام',
                child: _ThemeModeSelector(
                  themeMode: themeMode,
                  onChanged: (mode) =>
                      ref.read(themeModeProvider.notifier).setMode(mode),
                ),
              ),
              const _SectionDivider(),
              _SettingBlock(
                icon: Icons.palette_outlined,
                title: 'اللون المميز',
                subtitle: 'لون واحد للتأكيد داخل الواجهة',
                child: _AccentColorSelector(
                  accentColor: accentColor,
                  onChanged: (color) =>
                      ref.read(accentColorProvider.notifier).setColor(color),
                ),
              ),
            ],
          ),
          SizedBox(height: context.sectionGap),
          _SettingsSection(
            title: 'العرض',
            children: [
              _SettingBlock(
                icon: Icons.compress_outlined,
                title: 'كثافة العرض',
                subtitle: 'مريح للاستخدام اليومي أو مضغوط للبيانات',
                child: _DensitySelector(
                  density: density,
                  onChanged: (d) =>
                      ref.read(densityProvider.notifier).setDensity(d),
                ),
              ),
              const _SectionDivider(),
              _SettingBlock(
                icon: Icons.crop_square_rounded,
                title: 'نمط البطاقات',
                subtitle: 'إطار، مسطح، أو ظل خفيف',
                child: _CardStyleSelector(
                  cardStyle: cardStyle,
                  onChanged: (s) =>
                      ref.read(cardStyleProvider.notifier).setStyle(s),
                ),
              ),
            ],
          ),
          SizedBox(height: context.sectionGap),
          _SettingsSection(
            title: 'الهوية',
            children: [
              _SettingBlock(
                icon: Icons.person_outline,
                title: 'اسم الواجهة',
                subtitle: 'يظهر في تحية الصفحة الرئيسية',
                child: _CreatorNameField(
                  creatorName: creatorName,
                  onChanged: (name) =>
                      ref.read(creatorNameProvider.notifier).setName(name),
                ),
              ),
            ],
          ),
          SizedBox(height: context.sectionGap),
          _SettingsSection(
            title: 'التذكيرات',
            children: [
              _SettingBlock(
                icon: Icons.notifications_active_outlined,
                title: 'تذكير يومي',
                subtitle: 'ينبهك لتسجيل وجبة اليوم',
                child: _ReminderSelector(
                  settings: reminder,
                  onToggle: (enabled) async {
                    final ok = await ref
                        .read(reminderProvider.notifier)
                        .setEnabled(enabled);
                    if (!ok && context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content:
                              Text('فعّل صلاحية الإشعارات من إعدادات الجهاز'),
                        ),
                      );
                    }
                  },
                  onPickTime: () async {
                    final picked = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay(
                        hour: reminder.hour,
                        minute: reminder.minute,
                      ),
                    );
                    if (picked == null) return;
                    final ok = await ref
                        .read(reminderProvider.notifier)
                        .setTime(picked.hour, picked.minute);
                    if (!ok && context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content:
                              Text('تعذر تفعيل التذكير بدون صلاحية الإشعارات'),
                        ),
                      );
                    }
                  },
                ),
              ),
            ],
          ),
          SizedBox(height: context.sectionGap),
          _SettingsSection(
            title: 'البيانات',
            children: [
              _SettingBlock(
                icon: Icons.backup_outlined,
                title: 'النسخ الاحتياطي',
                subtitle: 'صدّر نسخة JSON أو استعد بياناتك من نسخة سابقة',
                child: _BackupActions(
                  onExport: () => _exportBackup(context),
                  onImport: () => _importBackup(context, ref),
                ),
              ),
              const _SectionDivider(),
              _SettingBlock(
                icon: Icons.delete_forever_outlined,
                title: 'حذف البيانات كاملة',
                subtitle:
                    'يحذف القوائم والأعضاء والسجلات والسدادات من هذا الجهاز',
                child: _DangerResetButton(
                  onPressed: () => _deleteAllData(context, ref),
                ),
              ),
            ],
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  Future<void> _exportBackup(BuildContext context) async {
    try {
      final file = await const BackupService().exportJson();
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path)],
          subject: 'نسخة احتياطية من قطّه',
          text: 'نسخة احتياطية من بيانات تطبيق قطّه',
        ),
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تجهيز النسخة الاحتياطية')),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تصدير النسخة: $e')),
      );
    }
  }

  Future<void> _importBackup(BuildContext context, WidgetRef ref) async {
    final confirm = await showAppConfirmSheet(
      context,
      title: 'استعادة نسخة احتياطية؟',
      message: 'سيتم استبدال البيانات الحالية ببيانات النسخة المختارة.',
      confirmLabel: 'اختيار نسخة',
      icon: Icons.restore_outlined,
      destructive: false,
    );
    if (!confirm || !context.mounted) return;

    try {
      final file = await openFile(
        acceptedTypeGroups: const [
          XTypeGroup(label: 'JSON', extensions: ['json']),
        ],
      );
      final path = file?.path;
      if (path == null || path.isEmpty) return;

      await const BackupService().importJsonFile(File(path));
      _invalidateDataProviders(ref);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت استعادة النسخة الاحتياطية')),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر استعادة النسخة: $e')),
      );
    }
  }

  Future<void> _deleteAllData(BuildContext context, WidgetRef ref) async {
    final confirm = await showAppConfirmSheet(
      context,
      title: 'حذف كل البيانات؟',
      message:
          'سيتم حذف كل القوائم والأعضاء والسجلات والسدادات. لا يمكن التراجع إلا إذا عندك نسخة احتياطية.',
      confirmLabel: 'حذف كل البيانات',
      icon: Icons.delete_forever_outlined,
    );
    if (!confirm) return;

    try {
      await const BackupService().deleteAll();
      _invalidateDataProviders(ref);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حذف كل البيانات')),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر حذف البيانات: $e')),
      );
    }
  }

  void _invalidateDataProviders(WidgetRef ref) {
    ref.invalidate(listsProvider);
    ref.invalidate(membersProvider);
    ref.invalidate(mealTypesProvider);
    ref.invalidate(recordsProvider);
    ref.invalidate(allParticipantsProvider);
    ref.invalidate(participantsProvider);
    ref.invalidate(paymentsProvider);
    ref.invalidate(reportDataProvider);
  }
}

class _BackupActions extends StatelessWidget {
  final VoidCallback onExport;
  final VoidCallback onImport;

  const _BackupActions({
    required this.onExport,
    required this.onImport,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: onExport,
            icon: const Icon(Icons.upload_file_outlined),
            label: const Text('تصدير'),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: FilledButton.icon(
            onPressed: onImport,
            icon: const Icon(Icons.restore_outlined),
            label: const Text('استيراد'),
          ),
        ),
      ],
    );
  }
}

class _DangerResetButton extends StatelessWidget {
  final VoidCallback onPressed;

  const _DangerResetButton({required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onPressed,
      icon: const Icon(Icons.delete_forever_outlined),
      label: const Text('حذف كل البيانات'),
      style: OutlinedButton.styleFrom(
        foregroundColor: HesabnaColors.lightDanger,
        side: const BorderSide(color: HesabnaColors.lightDanger),
        minimumSize: const Size(double.infinity, 48),
      ),
    );
  }
}

class _ReminderSelector extends StatelessWidget {
  final ReminderSettings settings;
  final ValueChanged<bool> onToggle;
  final VoidCallback onPickTime;

  const _ReminderSelector({
    required this.settings,
    required this.onToggle,
    required this.onPickTime,
  });

  @override
  Widget build(BuildContext context) {
    final timeLabel = TimeOfDay(
      hour: settings.hour,
      minute: settings.minute,
    ).format(context);

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: context.cHover,
            borderRadius: BorderRadius.circular(HesabnaRadius.md),
            border: Border.all(color: context.cBorder),
          ),
          child: SwitchListTile.adaptive(
            value: settings.enabled,
            onChanged: onToggle,
            activeThumbColor: context.accentColor,
            contentPadding: EdgeInsets.zero,
            title: Text(
              settings.enabled ? 'التذكير مفعل' : 'التذكير متوقف',
              style: HesabnaTypography.subtitle(color: context.cText),
            ),
            subtitle: Text(
              settings.enabled
                  ? 'سيصلك تذكير يومياً الساعة $timeLabel'
                  : 'فعّله إذا تبغى تنبيه يومي',
              style: HesabnaTypography.caption(color: context.cTextMuted),
            ),
          ),
        ),
        const SizedBox(height: 10),
        InkWell(
          onTap: onPickTime,
          borderRadius: BorderRadius.circular(HesabnaRadius.md),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            decoration: BoxDecoration(
              color: context.cCard,
              borderRadius: BorderRadius.circular(HesabnaRadius.md),
              border: Border.all(color: context.cBorder),
            ),
            child: Row(
              children: [
                Icon(Icons.schedule_outlined,
                    size: 18, color: context.accentColor),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'وقت التذكير',
                    style: HesabnaTypography.body(color: context.cText),
                  ),
                ),
                Text(
                  timeLabel,
                  style:
                      HesabnaTypography.amountSmall(color: context.accentColor)
                          .copyWith(fontSize: 16),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _SettingsSection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _SettingsSection({
    required this.title,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Text(title,
              style: HesabnaTypography.subtitle(color: context.cText)),
        ),
        HesabnaCard(
          padding: EdgeInsets.zero,
          child: Column(children: children),
        ),
      ],
    );
  }
}

class _SettingBlock extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget child;

  const _SettingBlock({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(context.cardPad),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: context.cHover,
                  borderRadius: BorderRadius.circular(HesabnaRadius.md),
                ),
                child: Icon(icon, size: 20, color: context.cTextSub),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style:
                            HesabnaTypography.subtitle(color: context.cText)),
                    Text(subtitle,
                        style:
                            HesabnaTypography.caption(color: context.cTextSub)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _SectionDivider extends StatelessWidget {
  const _SectionDivider();

  @override
  Widget build(BuildContext context) {
    return Divider(height: 1, color: context.cDivider);
  }
}

class _ThemeModeSelector extends StatelessWidget {
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onChanged;

  const _ThemeModeSelector({
    required this.themeMode,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _ThemeModeButton(
          label: 'فاتح',
          icon: Icons.light_mode,
          isSelected: themeMode == ThemeMode.light,
          onTap: () => onChanged(ThemeMode.light),
        ),
        const SizedBox(width: 8),
        _ThemeModeButton(
          label: 'داكن',
          icon: Icons.dark_mode,
          isSelected: themeMode == ThemeMode.dark,
          onTap: () => onChanged(ThemeMode.dark),
        ),
        const SizedBox(width: 8),
        _ThemeModeButton(
          label: 'تلقائي',
          icon: Icons.brightness_auto,
          isSelected: themeMode == ThemeMode.system,
          onTap: () => onChanged(ThemeMode.system),
        ),
      ],
    );
  }
}

class _ThemeModeButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _ThemeModeButton({
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(HesabnaRadius.full),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(
            color: isSelected ? context.cText : context.cHover,
            borderRadius: BorderRadius.circular(HesabnaRadius.full),
            border: Border.all(
              color: isSelected ? context.cText : Colors.transparent,
            ),
          ),
          child: Column(
            children: [
              Icon(icon, color: isSelected ? context.cBg : context.cTextSub),
              const SizedBox(height: 4),
              Text(
                label,
                style: HesabnaTypography.caption(color: context.cTextMuted)
                    .copyWith(
                  color: isSelected ? context.cBg : context.cTextSub,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AccentColorSelector extends StatelessWidget {
  final Color accentColor;
  final ValueChanged<Color> onChanged;

  const _AccentColorSelector({
    required this.accentColor,
    required this.onChanged,
  });

  static const _colors = [
    Color(0xFF2563EB),
    Color(0xFF16A34A),
    Color(0xFF7C3AED),
    Color(0xFFDC2626),
  ];

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: _colors.map((color) {
        final isSelected = color == accentColor;
        return InkWell(
          onTap: () => onChanged(color),
          borderRadius: BorderRadius.circular(HesabnaRadius.full),
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(HesabnaRadius.full),
              border: Border.all(
                color: isSelected ? context.cText : context.cBorder,
                width: isSelected ? 3 : 1,
              ),
            ),
            child: isSelected
                ? const Icon(Icons.check, color: Colors.white)
                : null,
          ),
        );
      }).toList(),
    );
  }
}

class _DensitySelector extends StatelessWidget {
  final AppDensity density;
  final ValueChanged<AppDensity> onChanged;

  const _DensitySelector({
    required this.density,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _DensityButton(
          label: 'مريح',
          isSelected: density == AppDensity.comfortable,
          onTap: () => onChanged(AppDensity.comfortable),
        ),
        const SizedBox(width: 8),
        _DensityButton(
          label: 'مضغوط',
          isSelected: density == AppDensity.compact,
          onTap: () => onChanged(AppDensity.compact),
        ),
      ],
    );
  }
}

class _DensityButton extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _DensityButton({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(HesabnaRadius.full),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? context.cText : context.cHover,
            borderRadius: BorderRadius.circular(HesabnaRadius.full),
            border: Border.all(
              color: isSelected ? context.cText : Colors.transparent,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: HesabnaTypography.body(color: context.cText).copyWith(
              color: isSelected ? context.cBg : context.cTextSub,
            ),
          ),
        ),
      ),
    );
  }
}

class _CardStyleSelector extends StatelessWidget {
  final AppCardStyle cardStyle;
  final ValueChanged<AppCardStyle> onChanged;

  const _CardStyleSelector({
    required this.cardStyle,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _CardStyleButton(
          label: 'إطار',
          isSelected: cardStyle == AppCardStyle.bordered,
          onTap: () => onChanged(AppCardStyle.bordered),
        ),
        const SizedBox(width: 8),
        _CardStyleButton(
          label: 'مسطح',
          isSelected: cardStyle == AppCardStyle.flat,
          onTap: () => onChanged(AppCardStyle.flat),
        ),
        const SizedBox(width: 8),
        _CardStyleButton(
          label: 'ظل',
          isSelected: cardStyle == AppCardStyle.shadow,
          onTap: () => onChanged(AppCardStyle.shadow),
        ),
      ],
    );
  }
}

class _CardStyleButton extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _CardStyleButton({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(HesabnaRadius.full),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? context.cText : context.cHover,
            borderRadius: BorderRadius.circular(HesabnaRadius.full),
            border: Border.all(
              color: isSelected ? context.cText : Colors.transparent,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: HesabnaTypography.body(color: context.cText).copyWith(
              color: isSelected ? context.cBg : context.cTextSub,
            ),
          ),
        ),
      ),
    );
  }
}

class _CreatorNameField extends StatefulWidget {
  final String creatorName;
  final ValueChanged<String> onChanged;

  const _CreatorNameField({
    required this.creatorName,
    required this.onChanged,
  });

  @override
  State<_CreatorNameField> createState() => _CreatorNameFieldState();
}

class _CreatorNameFieldState extends State<_CreatorNameField> {
  late final _controller = TextEditingController(text: widget.creatorName);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: _controller,
      textAlign: TextAlign.right,
      decoration: InputDecoration(
        hintText: 'أدخل اسم المنشئ',
        suffixIcon: IconButton(
          icon: const Icon(Icons.check),
          onPressed: () => widget.onChanged(_controller.text),
        ),
      ),
      onSubmitted: widget.onChanged,
    );
  }
}
